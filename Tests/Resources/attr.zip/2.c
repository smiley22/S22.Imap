#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>


#include "form_reg.my"
#include "prot_f.my"



int main()
{
  Attractor * begin[G_steps];
  long int *** picture;

  point_type point[N];
  int number=0;
  int i=0,ii=0;

  if( !(picture=(long int * * *)malloc(sizeof(long int **)*G_steps)) )
                {printf("Picture: Out of memory\n"); exit(1);}

  for (i=0;i<G_steps;i++)
  {  if( !(picture[i]=(long int * *)malloc(sizeof(long int *) *NN[PLATE_X])) )
                {printf("Picture: Out of memory\n"); exit(1);}
     for (ii=0;ii<NN[PLATE_X];ii++)
      if( !(picture[i][ii]=(long int*)malloc(sizeof(long int)*NN[PLATE_Y])) )
                {printf("Picture: %d Out of memory\n",i); exit(1);}
   }

   init_picture(picture);

   for(i=0;i<G_steps;i++)
       begin[i]=NULL;

  while ( !make_init_point(point,number) )
    {
         make_form_and_add_point(point,begin,picture);
         number++; 
//            if(number)
         if(number%1000==0) printf("%d\n",number);
    }

          print_picture(begin,picture);

  return 0;

}

void init_picture(long int * * * picture)
  {
      int i0,i1,i;
      for (i = 0; i < G_steps; i++)
      for (i0 = 0; i0 < NN[PLATE_X]; i0++)
      for (i1 = 0; i1 < NN[PLATE_Y]; i1++)
          picture[i][i0][i1]=0;
    return;
  }




int make_init_point(point_type * point, int number)
  {

      int i=0, j=0, n_point=0, Number=1;
      int n=0;

    for (j=0;j<POINTS;j++)
    for (i=0;i<N;i++)
       reg[j].HN[i]=(reg[j].RN[i]-reg[j].LN[i])/(double)reg[j].NN[i];

    for (j=0;j<POINTS;j++)
     {    Number=1;
       for (i=0;i<N;i++)Number*=reg[j].NN[i];
       if(Number>number)break;
       number=number-Number; n_point++;
     }
     if( n_point >= POINTS ) return 1;

    // printf("numberpoint=%d ",n_point);

    for (i=0;i<N;i++)
     {    Number/=reg[n_point].NN[i];
          n=number/Number;
          number%=Number;
          point[i]=reg[n_point].LN[i]+reg[n_point].HN[i]*((double)n+0.50);
      }

    for (i=0;i<N;i++)
     {
//          printf("<%lf> ",point[i]);
      }
//      printf("\n");

     return 0;
 }

void make_form_and_add_point(point_type * point, Attractor * begin[], long int *** picture)
 {
    int global_step=0;
    int local_step=0;

for(global_step=0;global_step < G_steps;global_step++)
{
     for (local_step=0;local_step<L_steps;local_step++)
      {
       make_form(point);
      }
//       printf("W %lf %lf W\n",point[0],point[1]);
  if (PICTURE_ONLY==1)
          add_point_to_picture(point,picture[global_step],1);
        else
     begin[global_step]=add_point_to_attractor(point,begin[global_step]);

 }
     return;
 }

void add_point_to_picture(point_type * point,long int ** picture,int key)
 {
      point_type HN[N];
      int IN[N];
      int i=0;

    for (i=0;i<N;i++)
     {
       HN[i]=(RN[i]-LN[i])/(double) NN[i];
        IN[i]=(int)( (point[i]-LN[i])/HN[i] );
        if( (IN[i]<0)||(IN[i]>=NN[i]) ) return;
      }

       picture[ IN[ PLATE_X ] ][ IN[ PLATE_Y ] ] += key;

      return ;
 }

Attractor * add_point_to_attractor(point_type * point, Attractor * root)
 {   int i=0; int dir=0;
     Attractor *pos,*old;

     if(root==NULL) {
            pos=(Attractor *)malloc(sizeof(Attractor));
            if(!pos){printf("Attractor: Out of memory\n"); exit(2);}
            for (i=0;i<N;i++)
            { pos->point[i]=point[i];}
              pos->number=1;
              pos->left=NULL;
              pos->right=NULL;
              return pos;
            }

        for(pos=root;pos; )
 {         old = pos;
           i=point_compare(pos,point);
   if(i>0)
         { pos=pos->left; dir=0;}
    else if(i<0)
         { pos=pos->right; dir=1;}
    else
        { pos->number++; return root; }
    }
            pos=(Attractor *)malloc(sizeof(Attractor));
            if(!pos){printf("Add Point to Attractor: Out of memory\n"); exit(2);}
            for (i=0;i<N;i++)
             {pos->point[i]=point[i];}
            pos->number=1;
            pos->left=NULL;
            pos->right=NULL;

           if(dir == 1) old->right=pos;
             else
            old->left=pos;

            return root;
 }


int point_compare(Attractor * current, point_type * point)
{
      point_type HN[N];
      point_type dist=0.0;
      int i=0;

       for (i=0;i<N;i++) HN[i]=(RN[i]-LN[i])/(double)NN[i];

      for (i=0; i<N;i++)
        {  dist=current->point[i]-point[i];
           if( fabs(dist) > EPS_EQUIV ){i=signum(dist); /* printf("POINT %d COMP",i);*/ return i;}
        }

//       printf("POINT !!!!! COMP",i);
       return 0;
}

void   print_picture(Attractor * begin[],long int *** picture)
{
    char name[33];
    int i,i0,i1;
    int i_picture=0;
    FILE *out;

for(i_picture=0;i_picture<G_steps;i_picture++)
{    
    if (PICTURE_ONLY!=1)add_point_from_attracotr_to_picture(begin[i_picture],picture[i_picture]);
     sprintf(name,"%d", i_picture+1);
     strcat(name,".dat");
    out= fopen(name,"w");
        fprintf(out,"%d   ", NN[PLATE_X]);
        fprintf(out,"%d  \n",NN[PLATE_Y]);

          for(i1=NN[PLATE_Y]-1; i1 >= 0; i1--)
           { for(i0=0;i0 < NN[PLATE_X]; i0++)
               fprintf(out," %d", picture[i_picture][i0][i1]);
            fprintf(out,"\n");
             }
       fclose(out);
}
       return ;
 }



void  add_point_from_attracotr_to_picture(Attractor * current, long int **picture)
 {
      int i=0;

      if(current==NULL)return;

       add_point_from_attracotr_to_picture(current->left,picture);
        add_point_to_picture(current->point,picture,current->number);
       add_point_from_attracotr_to_picture(current->right,picture);
  return;
  }

void print_attractor(Attractor * current)
 {
     int i=0;

     if(current==NULL) return ;
        print_attractor(current->left);
          for (i=0;i<N;i++) printf(" %lf ",current->point[i]);
          printf(" %d \n",current->number);
        print_attractor(current->right);
   return ;
}


