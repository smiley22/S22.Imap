#include<math.h>

     typedef double point_type;
#define N     3
void make_form(point_type * point)
{
    const double tau=0.001;
    const double delta=10.0;
    const double r=28.0;
    const double b=8./3.;

    point_type newpoint[N];

    newpoint[0]=point[0] + tau*delta*( point[1]-point[0] );
    newpoint[1]=point[1] + tau*( r*point[0] - point[1] - point[0]*point[2] );
    newpoint[2]=point[2] + tau*( point[0]*point[1] -b*point[2] );
    point[0]=newpoint[0];
    point[1]=newpoint[1];
    point[2]=newpoint[2];

 return ;
}
